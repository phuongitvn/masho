<?php
require_once(dirname(dirname(__FILE__)) . '/m/app/M_Controller.php');
M_Controller::main_CLI('M_Controller', 'batch_regular_event');
?>