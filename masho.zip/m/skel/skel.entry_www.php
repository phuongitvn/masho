<?php
/**
 *  {$action_name}.php
 *
 *  @author     {$author}
 *  @package    M
 *  @version    $Id$
 */
require_once '{$dir_app}/M_Controller.php';

M_Controller::main('M_Controller', '{$action_name}');
?>
