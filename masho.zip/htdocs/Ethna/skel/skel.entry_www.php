<?php
/**
 *  {$action_name}.php
 *
 *  @author     {$author}
 *  @package    {$project_id}
 *  @version    $Id$
 */
require_once '{$dir_app}/{$project_id}_Controller.php';

{$project_id}_Controller::main('{$project_id}_Controller', '{$action_name}');
?>
