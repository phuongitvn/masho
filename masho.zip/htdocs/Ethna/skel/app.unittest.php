<?php
/**
 *  {$project_id}_UnitTestManager.php
 *
 *  @author     {$author}
 *  @package    {$project_id}
 *  @version    $Id$
 */

/**
 *  {$project_id} Unit Test Manager Class.
 *
 *  @author     {$author}
 *  @access     public
 *  @package    {$project_id}
 */
class {$project_id}_UnitTestManager extends Ethna_UnitTestManager
{
    /**
     *  @var    array   General test case definition.
     */
    var $testcase = array(
        /*
         *  TODO: Write general test case definition here.
         *
         *  Example:
         *
         *  'util' => 'app/UtilTest.php',
         */
    );
}
?>
