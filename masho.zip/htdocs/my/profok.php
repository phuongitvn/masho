<?php
require_once dirname(dirname(dirname(__FILE__))) . '/m/app/M_Controller.php';

M_Controller::main('M_Controller', 'my_profok');
?>
