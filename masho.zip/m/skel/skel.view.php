<?php
/**
 *  {$view_path}
 *
 *  @author     {$author}
 *  @package    M
 *  @version    $Id$
 */

/**
 *  {$forward_name} view implementation.
 *
 *  @author     {$author}
 *  @access     public
 *  @package    M
 */
class {$view_class} extends M_ViewClass
{
    /**
     *  preprocess before forwarding.
     *
     *  @access public
     */
    function preforward()
    {
    }
}

?>
