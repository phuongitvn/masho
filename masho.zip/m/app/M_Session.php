<?php
class M_Session extends Ethna_Session
{
	function isValid() {
		return TRUE;
	}
}
