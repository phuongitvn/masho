<?php
// vim: foldmethod=marker
/**
 *  {$project_id}_ViewClass.php
 *
 *  @author     {$author}
 *  @package    {$project_id}
 *  @version    $Id$
 */

// {{{ {$project_id}_ViewClass
/**
 *  View class.
 *
 *  @author     {$author}
 *  @package    {$project_id}
 *  @access     public
 */
class {$project_id}_ViewClass extends Ethna_ViewClass
{
    /**
     *  set common default value.
     *
     *  @access protected
     *  @param  object  {$project_id}_Renderer  Renderer object.
     */
    function _setDefault(&$renderer)
    {
    }

}
// }}}

?>
