<?php
require_once '{$basedir}/app/{$project_id}_Controller.php';

{$project_id}_Controller::main_XMLRPC('{$project_id}_Controller');
?>
