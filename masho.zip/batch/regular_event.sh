#!/bin/bash
php -f /var/www/html/masho/batch/regular_event.php
