<?php
class M_BatchManager extends M_Manager
{
	function getMaintainanceStatus() {
		return 0;
	}
}
?>
