<?php
require_once '/home/yarr2jp/m/app/M_Controller.php';

M_Controller::main_XMLRPC('M_Controller');
?>
