<?php
class M_ClientBackend extends Ethna_Backend {
	function M_ClientBackend(&$controller) {
		parent::Ethna_Backend($controller);
	}
}
?>